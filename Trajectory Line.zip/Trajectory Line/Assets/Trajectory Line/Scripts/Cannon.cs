using UnityEngine;

public class Cannon : MonoBehaviour
{
    [SerializeField]
    private Projection m_projection;

    private void Update()
    {
        HandleControls();
        m_projection.SimulateTrajectory(m_BallPrefab, m_BallSpawn.position, m_BallSpawn.forward * m_Force);
    }

    #region Handle Controls

    [SerializeField] private Ball m_BallPrefab;
    [SerializeField] private float m_Force = 20;
    [SerializeField] private Transform m_BallSpawn;
    [SerializeField] private Transform m_BarrelPivot;
    [SerializeField] private float m_RotateSpeed = 30;
    [SerializeField] private AudioSource m_Source;
    [SerializeField] private AudioClip m_Clip;
    [SerializeField] private Transform m_LeftWheel, m_RightWheel;

    private void HandleControls()
    {
        if (Input.GetKey(KeyCode.S)) m_BarrelPivot.Rotate(Vector3.right * m_RotateSpeed * Time.deltaTime);
        else if (Input.GetKey(KeyCode.W)) m_BarrelPivot.Rotate(Vector3.left * m_RotateSpeed * Time.deltaTime);

        if (Input.GetKey(KeyCode.A))
        {
            transform.Rotate(Vector3.down * m_RotateSpeed * Time.deltaTime);
            m_LeftWheel.Rotate(Vector3.forward * m_RotateSpeed * Time.deltaTime);
            m_RightWheel.Rotate(Vector3.back * m_RotateSpeed * Time.deltaTime);
        }
        else if (Input.GetKey(KeyCode.D))
        {
            transform.Rotate(Vector3.up * m_RotateSpeed * Time.deltaTime);
            m_LeftWheel.Rotate(Vector3.back * m_RotateSpeed * 1.5f * Time.deltaTime);
            m_RightWheel.Rotate(Vector3.forward * m_RotateSpeed * 1.5f * Time.deltaTime);
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            var spawned = Instantiate(m_BallPrefab, m_BallSpawn.position, m_BallSpawn.rotation);

            spawned.Init(m_BallSpawn.forward * m_Force, false);
            m_Source.PlayOneShot(m_Clip);
        }
    }

    #endregion
}