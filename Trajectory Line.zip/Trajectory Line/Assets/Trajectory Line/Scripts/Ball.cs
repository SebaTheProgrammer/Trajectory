using UnityEngine;

public class Ball : MonoBehaviour
{
    [SerializeField]
    private Rigidbody m_Rb;

    [SerializeField]
    private AudioSource m_AudioSrc;

    [SerializeField]
    private AudioClip[] m_ArrOfAudioClips;

    private bool m_IsGhost;

    public void Init(Vector3 velocity, bool isGhost)
    {
        m_IsGhost = isGhost;
        m_Rb.AddForce(velocity, ForceMode.Impulse);
    }

    public void OnCollisionEnter(Collision col)
    {
        if (m_IsGhost) return;

        m_AudioSrc.clip = m_ArrOfAudioClips[Random.Range(0, m_ArrOfAudioClips.Length)];
        m_AudioSrc.Play();
    }
}