using UnityEngine;

public class Cannon : MonoBehaviour
{
    [SerializeField]
    private Projection m_projection;

    [SerializeField]
    private GameObject m_UiUnity;
    [SerializeField]
    private GameObject m_UiOwn;

    #region Handle Controls
    [SerializeField] private Ball m_BallPrefab;
    [SerializeField] private Rigidbody m_BallRb;
    [SerializeField] private float m_Force = 20;
    [SerializeField] private Transform m_BallSpawn;
    [SerializeField] private Transform m_BarrelPivot;
    [SerializeField] private float m_RotateSpeed = 30;
    [SerializeField] private AudioSource m_Source;
    [SerializeField] private AudioClip m_Clip;
    [SerializeField] private Transform m_LeftWheel, m_RightWheel;

    private bool m_UnityCalculations = true;

    private void Update()
    {
        HandleControls();

        if (m_UnityCalculations)
        {
            m_projection.SimulateTrajectory(m_BallPrefab, m_BallSpawn.position, m_BallSpawn.forward * m_Force);
        }
        else
        {
            m_projection.OwnProjectionCalculations(m_BallPrefab, m_BallRb.mass, m_BallSpawn.position, m_BallSpawn.forward * m_Force);
        }
    }

    private void HandleControls()
    {
        if (Input.GetKey(KeyCode.S)) m_BarrelPivot.Rotate(Vector3.right * m_RotateSpeed * Time.deltaTime);
        else if (Input.GetKey(KeyCode.W)) m_BarrelPivot.Rotate(Vector3.left * m_RotateSpeed * Time.deltaTime);

        if (Input.GetKey(KeyCode.A))
        {
            transform.Rotate(Vector3.down * m_RotateSpeed * Time.deltaTime);
            m_LeftWheel.Rotate(Vector3.forward * m_RotateSpeed * Time.deltaTime);
            m_RightWheel.Rotate(Vector3.back * m_RotateSpeed * Time.deltaTime);
        }
        else if (Input.GetKey(KeyCode.D))
        {
            transform.Rotate(Vector3.up * m_RotateSpeed * Time.deltaTime);
            m_LeftWheel.Rotate(Vector3.back * m_RotateSpeed * 1.5f * Time.deltaTime);
            m_RightWheel.Rotate(Vector3.forward * m_RotateSpeed * 1.5f * Time.deltaTime);
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            var spawned = Instantiate(m_BallPrefab, m_BallSpawn.position, m_BallSpawn.rotation);
            spawned.Init(m_BallSpawn.forward * m_Force, false, !m_UnityCalculations);

            m_Source.PlayOneShot(m_Clip);
        }

        if (Input.GetKeyDown(KeyCode.E))
        {
            m_UnityCalculations = !m_UnityCalculations;
            m_UiUnity.SetActive(m_UnityCalculations);
            m_UiOwn.SetActive(!m_UnityCalculations);
        }

        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            if (m_BallRb.mass < 30)
            {
                m_BallRb.mass += 5;
            }
        }
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            if (m_BallRb.mass > 5)
            {
                m_BallRb.mass -= 5;
            }
        }
    }
    #endregion
}