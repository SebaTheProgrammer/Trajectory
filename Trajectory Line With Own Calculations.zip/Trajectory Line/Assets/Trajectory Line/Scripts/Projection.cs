using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using static UnityEditor.PlayerSettings;

public class Projection : MonoBehaviour
{
    [SerializeField]
    private LineRenderer m_Line;

    [SerializeField]
    private int m_MaxPhysicsFrameIterations = 100;

    [SerializeField]
    private Transform m_ObstaclesParent;

    [SerializeField]
    private int m_LinePoints = 25;
    [SerializeField]
    [Range(0.01f, 0.25f)]
    private float m_TimeBetweenPoints = 0.1f;

    [SerializeField]
    private bool m_NeedToCreatePhisicsScene;

    private Scene m_SimulationScene;
    private PhysicsScene m_PhysicsScene;
    private readonly Dictionary<Transform, Transform> m_SpawnedObjects = new Dictionary<Transform, Transform>();

    private void Start()
    {
        if (m_NeedToCreatePhisicsScene)
        {
            CreatePhysicsScene();
        }
    }

    private void CreatePhysicsScene()
    {
        m_SimulationScene = SceneManager.CreateScene("Simulation", new CreateSceneParameters(LocalPhysicsMode.Physics3D));
        m_PhysicsScene = m_SimulationScene.GetPhysicsScene();

        foreach (Transform obj in m_ObstaclesParent)
        {
            var ghostObj = Instantiate(obj.gameObject, obj.position, obj.rotation);
            ghostObj.GetComponent<Renderer>().enabled = false;
            SceneManager.MoveGameObjectToScene(ghostObj, m_SimulationScene);

            if (!ghostObj.isStatic) m_SpawnedObjects.Add(obj, ghostObj.transform);
        }
    }

    private void Update()
    {
        foreach (var item in m_SpawnedObjects)
        {
            item.Value.position = item.Key.position;
            item.Value.rotation = item.Key.rotation;
        }
    }

    public void SimulateTrajectory(Ball ballPrefab, Vector3 pos, Vector3 velocity)
    {
        var ghostObj = Instantiate(ballPrefab, pos, Quaternion.identity);
        SceneManager.MoveGameObjectToScene(ghostObj.gameObject, m_SimulationScene);

        ghostObj.Init(velocity, true, false);

        m_Line.positionCount = m_MaxPhysicsFrameIterations;

        for (int i = 0; i < m_MaxPhysicsFrameIterations; i++)
        {
            m_PhysicsScene.Simulate(Time.fixedDeltaTime);
            m_Line.SetPosition(i, ghostObj.transform.position);
        }

        Destroy(ghostObj.gameObject);
    }

    public void OwnProjectionCalculations(Ball ballPrefab, float ballMass, Vector3 pos, Vector3 velocity)
    {
        Vector3 startVelocity = velocity / ballMass;
        m_Line.positionCount = Mathf.CeilToInt(m_LinePoints / m_TimeBetweenPoints) + 1;

        int i = 0;
        m_Line.SetPosition(i, pos);

        for (float time = 0; time < m_LinePoints; time += m_TimeBetweenPoints)
        {
            i++;
            Vector3 point = pos + time * startVelocity;
            //d = x+ u*t+1/2*g*t^2
            point.y = pos.y + startVelocity.y * time + (Physics.gravity.y * time * time) / 2;

            m_Line.SetPosition(i, point);
        }
    }
}