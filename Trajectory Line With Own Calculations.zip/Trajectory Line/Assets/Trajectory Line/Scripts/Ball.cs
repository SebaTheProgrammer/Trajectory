using UnityEngine;

public class Ball : MonoBehaviour
{
    [SerializeField]
    private float m_LifeTime = 10;

    [SerializeField]
    private Projection m_projection;

    [SerializeField] 
    private Ball m_BallPrefab;

    [SerializeField]
    private Rigidbody m_Rb;

    [SerializeField]
    private AudioSource m_AudioSrc;

    [SerializeField]
    private AudioClip[] m_ArrOfAudioClips;

    private bool m_IsGhost;
    private bool m_ExtraCalculations;

    private float m_TotalTime;

    private Vector3 m_BouncPos;
    private Vector3 m_Velocity;
    public void Init(Vector3 velocity, bool isGhost, bool extraCalculations)
    {
        m_IsGhost = isGhost;
        m_Rb.AddForce(velocity, ForceMode.Impulse);
        m_ExtraCalculations = extraCalculations;
    }

    public void OnCollisionEnter(Collision col)
    {
        if (m_IsGhost) return;

        m_AudioSrc.clip = m_ArrOfAudioClips[Random.Range(0, m_ArrOfAudioClips.Length)];
        m_AudioSrc.Play();

        m_BouncPos=this.gameObject.transform.position;
        m_Velocity = m_Rb.velocity*m_Rb.mass;
    }

    private void Update()
    {
        m_TotalTime += Time.deltaTime;

        if (m_ExtraCalculations)
        {
            m_projection.OwnProjectionCalculations(m_BallPrefab, m_Rb.mass, m_BouncPos, m_Velocity);
        }

        if (m_TotalTime > m_LifeTime)
        {
            Destroy(this.gameObject);
        }
    }
}